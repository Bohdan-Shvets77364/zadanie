const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Serwowanie statycznych plików z folderu "public"
app.use(express.static(path.join(__dirname, 'public')));

// Endpoint API – zwraca JSON z danymi studenta
app.get('/api/hello', (req, res) => {
  res.json({
    imie: 'Bohdan',
    nazwisko: 'Shvets',
    indeks: '77364'
  });
});

// Główny endpoint – zwraca zwykły tekst
app.get('/', (req, res) => {
  res.send('Witaj! Przejdź do /api/hello aby zobaczyć dane w JSON.');
});

app.listen(PORT, () => {
  console.log(`Serwer uruchomiony: http://localhost:${PORT}`);
});
