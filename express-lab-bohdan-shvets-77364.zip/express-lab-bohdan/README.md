# Express.js Lab – Bohdan Shvets (77364)

Prosta aplikacja Express.js na laboratorium.

## Uruchomienie

```bash
# 1. Zainstaluj zależności
npm install

# 2. Uruchom serwer
node index.js
```

Serwer startuje na http://localhost:3000

## Endpointy

| URL | Opis |
|-----|------|
| `http://localhost:3000/` | Strona HTML z danymi studenta |
| `http://localhost:3000/api/hello` | JSON z imieniem, nazwiskiem i indeksem |

## Dane studenta

```json
{
  "imie": "Bohdan",
  "nazwisko": "Shvets",
  "indeks": "77364"
}
```

## Struktura projektu

```
express-lab/
├── index.js          ← serwer Express.js
├── package.json
└── public/
    └── index.html    ← strona HTML (fetch do /api/hello)
```

## Sprawdzenie środowiska

```bash
node -v
npm -v
java --version
javac --version
```
